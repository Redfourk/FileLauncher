# FileLauncher
#### Welcome to FileLauncher! In this description, I'll highlight the purpose, future-functionality, prerequisites, and steps on how to install this program.
## DISCLAIMER:
FileLauncher is NOT a functional app by any standards whatsoever; in fact, I highly recommend for non-developers to avoid using the app until we reach version 1.0 of development. All features described in this description are included within the app, but might not be readily available until 1.0.

## Purpose
FileLauncher was designed to provide a purely-Python*, cross-platform, file transfer application that only required its own coding language and a few Python dependencies to function.

## Current Functionality

✅ - Implemented

🚧 - Planned / In Development

❌ - Not Planned

| Status | Feature                                                       |
|--------|---------------------------------------------------------------|
| ❌      | Support Below Python 3.12                                     |
| ❌      | CLI Functionality                                             |
| ✅      | Graphical Interface Functionality                             |
| 🚧     | Cross-Platform Support                                        |
| 🚧     | Google Authentication (working, just needs to be implemented) |
| 🚧     | File Transfer API Services                                    |
| 🚧     | Update Functionality within the app                           |

Stay tuned to see how this table changes :)

# Installation

### Prerequisites
The current version of the app requires that you meet these requirements:

- A computer with the Windows Operating System
- Python 3.12 or newer (If you currently have the MS store version installed, please uninstall it and use the installer on the Python website. The MS store version will never work with the app.)
- PIP, comes with any Python installation, no need to install this


### Getting the Package:
Open a command prompt or terminal where you have access to Python.

Then use any of the commands below to install the FileLauncher package through PyPI. (your command will vary by system)


```Batch
python -m pip install FileLauncher
```
```Batch
pip install FileLauncher
```
If you have a virtual environment or IDE you could even use something like:

```Batch
./.venv/scripts/python.exe -m pip install FileLauncher
```

### Launching the App:
From the terminal you installed from, you can run this command to launch the app.